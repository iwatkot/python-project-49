### Hexlet tests and linter status:
[![Actions Status](https://github.com/iwatkot/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/iwatkot/python-project-49/actions) <a href="https://codeclimate.com/github/iwatkot/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/80271090387fb34aaa7e/maintainability" /></a>

## Brain-even script example
[![asciicast](https://asciinema.org/a/XFXRk4Sdzfgs5JC7ZuBtU88Ln.svg)](https://asciinema.org/a/XFXRk4Sdzfgs5JC7ZuBtU88Ln)

## Brain-calc script example
[![asciicast](https://asciinema.org/a/U6h9WfhPQMH7d6ZcQoqRn3pAY.svg)](https://asciinema.org/a/U6h9WfhPQMH7d6ZcQoqRn3pAY)