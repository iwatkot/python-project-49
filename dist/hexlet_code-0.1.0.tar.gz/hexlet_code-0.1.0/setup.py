# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.games.brain_calc:main',
                     'brain-even = brain_games.games.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.games.brain_gcd:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/iwatkot/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/iwatkot/python-project-49/actions) <a href="https://codeclimate.com/github/iwatkot/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/80271090387fb34aaa7e/maintainability" /></a>\n\n## Brain-even script example\n[![asciicast](https://asciinema.org/a/XFXRk4Sdzfgs5JC7ZuBtU88Ln.svg)](https://asciinema.org/a/XFXRk4Sdzfgs5JC7ZuBtU88Ln)\n\n## Brain-calc script example\n[![asciicast](https://asciinema.org/a/U6h9WfhPQMH7d6ZcQoqRn3pAY.svg)](https://asciinema.org/a/U6h9WfhPQMH7d6ZcQoqRn3pAY)',
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
